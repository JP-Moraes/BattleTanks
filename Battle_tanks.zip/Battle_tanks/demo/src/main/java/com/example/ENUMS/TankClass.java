package com.example.ENUMS;

public enum TankClass {
    LIGHT, 
    MEDIUM,
    HEAVY
}
