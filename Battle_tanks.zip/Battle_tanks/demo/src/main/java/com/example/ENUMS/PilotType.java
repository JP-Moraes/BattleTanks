package com.example.ENUMS;

public enum PilotType {
    HUMAN,
    AI
}
    

