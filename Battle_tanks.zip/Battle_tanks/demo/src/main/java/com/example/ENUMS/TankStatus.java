package com.example.ENUMS;

public enum TankStatus {
    ACTIVE,
    DESTROYED,
    UNDER_REPAIR
    
}
