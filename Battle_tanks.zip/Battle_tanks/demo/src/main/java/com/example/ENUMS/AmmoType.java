package com.example.ENUMS;

public enum AmmoType {
    PIERCING, 
    SHATTERING, 
    EXPLOSIVE
}
